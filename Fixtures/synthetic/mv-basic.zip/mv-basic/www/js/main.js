PluginManager.setup($plugins);
